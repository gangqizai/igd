Fpt.efi -f AHWSA.bin
Fpt.efi -greset
